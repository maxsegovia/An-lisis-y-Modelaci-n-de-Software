#include <iostream>
#include <string>
#include <vector>

using namespace std;

class RadioFormula
{
    //string _departamento;
    vector<string> _persona = {"Pena Nieto", "Hillary", "Trump"};
    string name = "Radio Formula";
  public:
    
    string _noticia;
    RadioFormula(){}
    
    bool update(string persona)
    {
       for(int i = 0; i < _persona.size(); i++)
       {
            if(_persona[i].compare(persona) == 0)
               return true;
       }
       return false;
    }
};