#ifndef BSRVR
#define BSRVR

#include "Televisa.cpp"
#include "TVAzteca.cpp"
#include "RadioFormula.cpp"
#include "MVS.cpp"
#include "CNNNoticias.cpp"
#include <vector>

template<class T>
class Observer
{
    string _persona;
    vector<T> _Noticiero = {TVAzteca(),Televisa(),MVS(),RadioFormula(), CNNNoticias()};
    bool check;
  public:
    Observer():  T Noticiero(){}
    void set_noticia(string persona)
    {
        _persona = persona;
        notify();
    }
    void notify()
    {
        for(int i = 0; i <  _Noticiero.size(); i++)
        {
            check = _Noticiero[i].update(_persona);
            
            if (check)
                cout<<Noticiero.name << " esta hablando de  "<< Noticiero._noticia <<endl;
        }
    }
};

#endif