#include <iostream>
#include "Command.cpp"

using namespace std;

class Trump
{
    string name;
    Command cmd; 
    
    Trump( Command c): cmd(c)
    {
        name = "Trump";
    }
    
    void talk()
    {
        cout << name << " is talking" << endl;
        cmd.execute();
    }
}