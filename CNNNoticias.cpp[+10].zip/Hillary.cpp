#include <iostream>
#include "Command.cpp"

using namespace std;

class Hillary
{
    string name;
    Command cmd; 
    
    Hillary( Command c): cmd(c)
    {
        name = "Hillary";
    }
    
    void talk()
    {
        cout << name << " is talking" << endl;
        cmd.execute();
    }
}