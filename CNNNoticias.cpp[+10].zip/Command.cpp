#include "PenaNieto.cpp"
#include "Hillary.cpp"
#include "Trump.cpp"

template<class T>
class Command
{

    T *object; //    
    void(T :: *method)();
  public:
    Command(T *obj = 0, void(T :: *meth)() = 0)
    {
        object = obj;
        method = meth;
    }
    void execute()
    {
        (object-> *method)();
    }
};