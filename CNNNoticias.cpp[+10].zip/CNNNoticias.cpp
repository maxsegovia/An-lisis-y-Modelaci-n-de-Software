#include <iostream>
#include <string>
#include <vector>

using namespace std;

class CNNNoticias
{
    //string _departamento;
    vector<string> _persona = {"Hillary", "Trump"};
    string name = "CNN Noticias";
  public:
    
    string _noticia;
    CNNNoticias(){}
    
    bool update(string persona)
    {
       for(int i = 0; i < _persona.size(); i++)
       {
            if(_persona[i].compare(persona) == 0)
               return true;
       }
       return false;
    }
};