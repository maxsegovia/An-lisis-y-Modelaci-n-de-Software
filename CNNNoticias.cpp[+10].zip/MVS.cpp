#include <iostream>
#include <string>
#include <vector>

using namespace std;

class MVS
{
    //string _departamento;
    vector<string> _persona = {"Pena Nieto", "Hillary", "Trump"};
    string name = "MVS Noticias";
  public:
    
    string _noticia;
    MVS(){}
    
    bool update(string persona)
    {
       for(int i = 0; i < _persona.size(); i++)
       {
            if(_persona[i].compare(persona) == 0)
               return true;
       }
       return false;
    }
};