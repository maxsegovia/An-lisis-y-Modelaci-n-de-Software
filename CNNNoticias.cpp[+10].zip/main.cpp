#include "Observer.cpp"
#include "Command.cpp"


int main(){
    
  Observer noticia;
  
  PenaNieto penanieto(Command());
  Hillary hillary(Command());
  Trump trump(Command());
  
  
  noticia.set_noticia(penanieto.talk());
  noticia.set_noticia(hillary.talk());
  noticia.set_noticia(trump.talk());
  
  return 0;
}