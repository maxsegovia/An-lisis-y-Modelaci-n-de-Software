#include <iostream>
#include <string>
#include "Command.cpp"

using namespace std;
#include <iostream>

using namespace std;

class PenaNieto
{
    string name;
    Command cmd; 
    
    PenaNieto(Command c): cmd(c)
    {
        name = "Pena Nieto";
    }
    
    void talk()
    {
        cout << name << " is talking" << endl;
        cmd.execute();
    }
}