#include "Tablet.h"

Tablet::Tablet()
{
  //Code for constructor goes in here.
}

Tablet::~Tablet()
{
  //Code for destructor goes in here.
}

int Tablet::selected()
{
  //Code for selected goes in here.
	std::cout<<"You have chosen a Tablet computer."<<std::endl;
	return 0;
}
