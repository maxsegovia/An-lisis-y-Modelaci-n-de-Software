#include "Netbook.h"

Netbook::Netbook()
{
  //Code for constructor goes in here.
}

Netbook::~Netbook()
{
  //Code for destructor goes in here.
}

int Netbook::selected()
{
  //Code for selected goes in here.
	std::cout<<"You have chosen a Netbook computer."<<std::endl;
	return 0;
}
