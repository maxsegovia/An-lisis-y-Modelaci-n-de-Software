#include "Laptop.h"

Laptop::Laptop()
{
  //Code for constructor goes in here.
}

Laptop::~Laptop()
{
  //Code for destructor goes in here.
}

int Laptop::selected()
{
  //Code for selected goes in here.
	std::cout<<"You have chosen a Laptop computer."<<std::endl;

}
