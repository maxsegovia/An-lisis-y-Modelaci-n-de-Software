#ifndef CMPTR
#define CMPTR

#include <iostream>

class Computer{
  public:
    //Constructor
    Computer();

    //Destructor
    ~Computer();

    //Methods
    static int* selected();
};

#endif
