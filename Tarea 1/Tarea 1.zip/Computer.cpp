#include "Computer.h"

Computer::Computer()
{
  //Code for constructor goes in here.
}

Computer::~Computer()
{
  //Code for destructor goes in here.
}

int* Computer::selected()
{
  //Code for assigned function goes here.
	std::cout<<"You have chosen ";
	return 0;
}
