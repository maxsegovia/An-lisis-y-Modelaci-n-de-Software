#include "Desktop.h"

Desktop::Desktop()
{
  //Code for constructor goes in here.
}

Desktop::~Desktop()
{
  //Code for destructor goes in here.
}

int Desktop::selected()
{
  //Code for selected goes in here.
	std::cout<<"You have chosen a Desktop computer."<<std::endl;
	return 0;
}
