#include "ClonePastel.h"

class Pastel_Treleches : public clonePastel<Pastel_Treleches>{
    private:
        string _ingredientes;
        Pastel_Treleches(){}
        
        ~Pastel_Treleches(){}
        
        void setIngredientes(string ingredientes)
        {
            _ingredientes = ingredientes;
        }
        
        string getIngredientes()
        {
            return _ingredientes;
        }
        friend class FactoryConcrete;
    
};