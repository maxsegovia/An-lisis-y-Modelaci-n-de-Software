#ifndef FCTRY
#define FCTRY

#include "Pastel.h"

class Factory{
  public:
    //Constructor
    Factory();

    //Destructor
    ~Factory();

    //Methods
    virtual Pastel* factory_method(int a);
    Pastel* create(int a);
};

Factory::Factory()
{
  //Constructor goes here.
}

Factory::~Factory()
{
  //Destructor goes here.
}

Pastel* Factory::create(int a)
{
  Pastel* tipo_pastel = factory_method(a);
  tipo_pastel->selected();
  
  return tipo_pastel;
}

Pastel * Factory::factory_method(int a)
{
	return NULL;
}

#endif