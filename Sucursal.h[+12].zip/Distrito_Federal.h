#include "Sucursal.h"
#include "Factory.h"
#include <string>

class Distrito_Federal : public Sucursal
{
    private:
        string _ingredientes = "Chocolate, frutas, merengue";
    public:
        Distrito_Federal();
        ~Distrito_Federal();
        
        void build_pastel();
        void create_pastel();
        
        void build_ingredientes() = 0;
        void build_batido() = 0;
        void build_amasado() = 0;
        void build_decorado() = 0;
        void build_empacado() = 0;
        
        
};

void create_pastel()
{
    Factory* factory = new Factory();
    factory.create(1);
    factory.create(2);
}

void build_ingredientes()
{
    pastel->setIngredientes(_ingredientes);
    build_batido();
    build_amasado();
    build_horneado();
    build_decorado();
    build_empacado();
}

void build_batido()
{
    pastel->batido();
}

void build_amasado()
{
    pastel->amasado();
}

void build_horneado()
{
    pastel->horneado();
}

void build_decorado()
{
    pastel->decorado();
}

void build_empacado()
{
    pastel->empacado();
}