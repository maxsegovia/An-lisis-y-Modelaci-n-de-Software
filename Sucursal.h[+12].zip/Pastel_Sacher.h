#include "ClonePastel.h"

class Pastel_Sacher : public clonePastel<Pastel_Sacher>{
    private:
        string _ingredientes;
        Pastel_Sacher(){}
        
        ~Pastel_Sacher(){}
        
        void setIngredientes(string ingredientes)
        {
            _ingredientes = ingredientes;
        }
        
        string getIngredientes()
        {
            return _ingredientes;
        }
        friend class FactoryConcrete;
    
};