#include<iostream>

template<class T>
class Iterator;

template<class T>
class Iterator
{
    private:
        Iterator(){}
        Aggregate<T>* aggregate;
        int idx;
    
    public:

    Iterator(Aggregate<T>* aggregate) : idx(0), aggregate(aggregate)
    {}
    
    T next()
    {
        if(hasNext())
            return aggregate->lista[idx++];
        else
            return 0;
    }
    
    bool hasNext()
    {
        return (idx < aggregate->getPos());
    }
    ~Iterator(){}

};


