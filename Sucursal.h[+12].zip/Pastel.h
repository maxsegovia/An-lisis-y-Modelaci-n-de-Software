#ifndef PSTL
#define PSTL

#include <iostream>
#include <string>
#include "clonePastel.h"

class Pastel{
    private:
        string _ingredientes;
        Pastel(){}
        
        ~Pastel(){}
        
        void batido()
        {
            std::cout<<"Batiendo..."<<endl;
        }
        
        void amasado()
        {
            std::cout<<"Amasando..."<<endl;
        }
        
        void horneado()
        {
            std::cout<<"Horneando..."<<endl;
        }
        
        void decorado()
        {
            std::cout<<"Decorando..."<<endl;
        }
        
        void empacado()
        {
            std::cout<<"Empacando..."<<endl;
        }
        
        void setIngredientes(string ingredientes)
        {
            _ingredientes = ingredientes;
        }
        
        string getIngredientes()
        {
            return _ingredientes;
        }
        
        
        virtual void Pastel* clonar() = 0;
        
        
};

#endif