#include "Iterator.h"

template<class T>
class Aggregate
{
public:
    friend class Iterator<T>;
    
    private:
        T* lista;
        int size;
        int pos;
    
    public: 
    Aggregate()
    {
        pos = 0;
        size = 10;
        lista = new T[size];
    }
    void add(T element)
    {
        if(pos < size)            
            lista[pos++] = element; 
    }
    Iterator<T>* getIterator()
    {
        return new Iterator<T>(this);
    }
    
    ~Aggregate()
    {
        delete [] lista;
    }

    T getElementAt(int pos){
        return lista[pos];
    }

    int getPos()
    {
        return pos;
    }  


};