#ifndef CLN
#define CLN


#include <iostream>
#include "Pastel.h"
#include "Pastel_Treleches.h"
#include "Pastel_Imposible.h"
#include "Pastel_Sacher.h

template <class SubClase>
class ClonePastel : public Pastel
{
public:
    virtual Pastel* clonar()
    {
        return new SubClase(dynamic_cast<SubClase&>(*this));    
    }
};

#endif
