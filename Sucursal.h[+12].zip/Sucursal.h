#ifndef SCRSL
#define SCRSL

#include <iostream>

class Sucursal{
    protected:
        Pastel* pastel;
    public:
        Sucursal_builder();
        ~Sucursal_builder();
        
        Pastel* build_pastel();
        virtual void create_pastel();
        
        virtual void build_ingredientes() = 0;
        virtual void build_batido() = 0;
        virtual void build_amasado() = 0;
        virtual void build_decorado() = 0;
        virtual void build_horneado() = 0;
        virtual void build_empacado() = 0;
        
};


Pastel* build_pastel()
{
    return pastel;
}

#endif
