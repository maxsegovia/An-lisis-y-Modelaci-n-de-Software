#include "clonePastel.h"

class Pastel_Imposible : public clonePastel<Pastel_Imposible>{
    private:
        string _ingredientes;
        Pastel_Imposible(){}
        
        ~Pastel_Imposible(){}
        
        void setIngredientes(string ingredientes)
        {
            _ingredientes = ingredientes;
        }
        
        string getIngredientes()
        {
            return _ingredientes;
        }
        friend class FactoryConcrete;
    
};